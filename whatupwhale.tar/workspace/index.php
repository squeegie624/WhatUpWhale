<?php
    require_once('inc/template.php');

?>

<html>
    <head>
        <title>WhatUpWhale</title>
        <link rel="stylesheet" href="assets/main.css" type="text/css" />
    </head>
    <body>
        <p class="big">Whatupwhale.com is currently under construction...</p>
        <p class="small">Please check back soon!</p>
    </body>
</html>